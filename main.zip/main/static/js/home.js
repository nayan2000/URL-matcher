$("#btn").click( function() {
    var url = "http://" + $("#text").val();
    window.open(url);
});
